package com.augms;

public class Main {
    public static void main(String[] args) {
        // Application entry point
        ApplicationConfig config = new ApplicationConfig();
        // Initialize application
    }
}
