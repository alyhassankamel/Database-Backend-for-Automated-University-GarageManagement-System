package com.augms;

public class ApplicationConfig {
    // Application configuration
}
