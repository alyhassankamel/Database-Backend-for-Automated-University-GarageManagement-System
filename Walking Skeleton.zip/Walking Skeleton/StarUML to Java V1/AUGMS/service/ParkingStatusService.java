package service;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ParkingStatusService {

    /**
     * Default constructor
     */
    public ParkingStatusService() {
    }

    /**
     * 
     */
    private final void parkingGarageDAO;

    /**
     * 
     */
    private final void parkingSpotDAO;

    /**
     * 
     */
    private final void occupancySensorDAO;

    /**
     * 
     */
    private final void parkingStatusDAO;







    /**
     * @return
     */
    public void checkCurrentStatus() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void aggregateData() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public Set<void> getAvailableSpots() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getOccupiedSpots() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public int countAvailableSlots() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public int countOccupiedSlots() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public void getParkingStatus() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public boolean isGarageAccessible() {
        // TODO implement here
        return false;
    }

    /**
     * @return
     */
    public void checkAccessPermissions() {
        // TODO implement here
        return null;
    }

}