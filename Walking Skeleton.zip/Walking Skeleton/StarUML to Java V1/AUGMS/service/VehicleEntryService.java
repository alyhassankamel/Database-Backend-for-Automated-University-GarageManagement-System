package service;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class VehicleEntryService {

    /**
     * Default constructor
     */
    public VehicleEntryService() {
    }

    /**
     * 
     */
    private final void vehicleDAO;

    /**
     * 
     */
    private final void parkingGarageDAO;

    /**
     * 
     */
    private final void occupancySensorDAO;

    /**
     * 
     */
    private final void entryGateDAO;






    /**
     * @return
     */
    public void validateRegistration() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void checkOccupancy() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void openGate() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void createEntryLog() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void incrementOccupiedSpots() {
        // TODO implement here
        return null;
    }

}