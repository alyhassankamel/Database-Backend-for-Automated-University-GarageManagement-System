package service;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class GarageAccessOverrideService {

    /**
     * Default constructor
     */
    public GarageAccessOverrideService() {
    }

    /**
     * 
     */
    private final void universityManagerDAO;




    /**
     * @return
     */
    public void setGlobalOverride() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void resetGlobalOverride() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void getCurrentOverrideStatus() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void logOverrideChange() {
        // TODO implement here
        return null;
    }

}