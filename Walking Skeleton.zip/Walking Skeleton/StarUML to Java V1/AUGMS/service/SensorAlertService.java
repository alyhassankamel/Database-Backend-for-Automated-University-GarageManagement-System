package service;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class SensorAlertService {

    /**
     * Default constructor
     */
    public SensorAlertService() {
    }

    /**
     * 
     */
    private final void sensorDAO;

    /**
     * 
     */
    private final void occupancySensorDAO;

    /**
     * 
     */
    private final void gateSensorDAO;

    /**
     * 
     */
    private final void garageAdminDAO;

    /**
     * 
     */
    private final void universityManagerDAO;








    /**
     * @return
     */
    public void performSelfDiagnostics() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void detectFault() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void generateErrorAlert() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void reportAlertToLogging() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void receiveSensorErrorAlert() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void notifyUniversityManager() {
        // TODO implement here
        return null;
    }

}