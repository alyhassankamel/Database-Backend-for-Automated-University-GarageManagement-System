package service;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class UserAccessService {

    /**
     * Default constructor
     */
    public UserAccessService() {
    }

    /**
     * 
     */
    private final void parkingUserDAO;




    /**
     * @return
     */
    public void findUser() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void updateAccess() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void validateAccess() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void confirmAccessChange() {
        // TODO implement here
        return null;
    }

}