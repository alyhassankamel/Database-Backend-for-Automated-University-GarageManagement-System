package service;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ReportService {

    /**
     * Default constructor
     */
    public ReportService() {
    }

    /**
     * 
     */
    private final void entryExitRepository;

    /**
     * 
     */
    private final void serviceLogRepository;

    /**
     * 
     */
    private final void logsDAO;





    /**
     * @return
     */
    public void compileUsageReport() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void generateReport() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void saveReport() {
        // TODO implement here
        return null;
    }

}