package service;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class PaymentService {

    /**
     * Default constructor
     */
    public PaymentService() {
    }

    /**
     * 
     */
    private final void paymentDAO;

    /**
     * 
     */
    private final void paymentMethodDAO;

    /**
     * 
     */
    private final void invoiceDAO;






    /**
     * @return
     */
    public void createPayment() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void processPayment() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordPaymentSuccess() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordPaymentFailure() {
        // TODO implement here
        return null;
    }

}