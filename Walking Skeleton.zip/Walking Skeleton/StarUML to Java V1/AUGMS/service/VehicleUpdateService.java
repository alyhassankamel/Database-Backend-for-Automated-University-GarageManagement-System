package service;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class VehicleUpdateService {

    /**
     * Default constructor
     */
    public VehicleUpdateService() {
    }

    /**
     * 
     */
    private final void vehicleDAO;

    /**
     * 
     */
    private final void parkingUserDAO;






    /**
     * @return
     */
    public void getVehicleDetails() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void validateVehicleOwnership() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void validateUpdatedData() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void updateVehicleDetails() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void saveUpdatedVehicle() {
        // TODO implement here
        return null;
    }

}