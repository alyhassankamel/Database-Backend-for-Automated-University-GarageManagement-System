package service;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ServiceRequestService {

    /**
     * Default constructor
     */
    public ServiceRequestService() {
    }

    /**
     * 
     */
    private final void serviceRequestDAO;

    /**
     * 
     */
    private final void parkingSpotDAO;

    /**
     * 
     */
    private final void serviceTypeDAO;

    /**
     * 
     */
    private final void parkingUserDAO;

    /**
     * 
     */
    private final void vehicleDAO;












    /**
     * @return
     */
    public void getSpotDetails() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void getAvailableServicesForSpot() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void createServiceRequest() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void associateRequester() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void associateVehicle() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void generateInvoice() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void processPayment() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void updateRequestStatus() {
        // TODO implement here
        return null;
    }

}