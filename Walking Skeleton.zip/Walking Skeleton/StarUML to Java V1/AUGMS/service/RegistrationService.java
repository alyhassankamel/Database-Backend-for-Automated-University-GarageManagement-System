package service;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class RegistrationService {

    /**
     * Default constructor
     */
    public RegistrationService() {
    }

    /**
     * 
     */
    private final void parkingUserDAO;

    /**
     * 
     */
    private final void vehicleDAO;





    /**
     * @return
     */
    public void createUser() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void createVehicle() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void associateVehicle() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void validateDetails() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void confirmRegistration() {
        // TODO implement here
        return null;
    }

}