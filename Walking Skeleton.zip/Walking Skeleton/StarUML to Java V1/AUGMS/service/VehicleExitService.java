package service;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class VehicleExitService {

    /**
     * Default constructor
     */
    public VehicleExitService() {
    }

    /**
     * 
     */
    private final void vehicleDAO;

    /**
     * 
     */
    private final void parkingGarageDAO;

    /**
     * 
     */
    private final void exitGateDAO;

    /**
     * 
     */
    private final void occupancySensorDAO;






    /**
     * @return
     */
    public void validateVehicle() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void getParkingDuration() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void processExit() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void openExitGate() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void updateSpotStatus() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordExit() {
        // TODO implement here
        return null;
    }

}