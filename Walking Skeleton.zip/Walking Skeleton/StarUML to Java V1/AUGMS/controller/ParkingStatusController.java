package controller;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ParkingStatusController {

    /**
     * Default constructor
     */
    public ParkingStatusController() {
    }



    /**
     * @return
     */
    public void handleLiveOccupancyRequest() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void handleStatusUpdate() {
        // TODO implement here
        return null;
    }

}