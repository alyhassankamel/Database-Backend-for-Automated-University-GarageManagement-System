package controller;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class SensorAlertController {

    /**
     * Default constructor
     */
    public SensorAlertController() {
    }



    /**
     * @return
     */
    public void handleSensorAlert() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void handleErrorLogRequest() {
        // TODO implement here
        return null;
    }

}