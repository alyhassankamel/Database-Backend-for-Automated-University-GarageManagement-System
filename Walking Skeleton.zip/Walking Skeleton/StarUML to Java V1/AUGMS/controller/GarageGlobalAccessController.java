package controller;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class GarageGlobalAccessController {

    /**
     * Default constructor
     */
    public GarageGlobalAccessController() {
    }



    /**
     * @param mode 
     * @param reason 
     * @return
     */
    public void handleOverrideRequest(String mode, String reason) {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void handleResetRequest() {
        // TODO implement here
        return null;
    }

}