package controller;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class VehicleUpdateController {

    /**
     * Default constructor
     */
    public VehicleUpdateController() {
    }



    /**
     * @return
     */
    public void handleVehicleUpdateRequest() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void handleUpdateConfirmation() {
        // TODO implement here
        return null;
    }

}