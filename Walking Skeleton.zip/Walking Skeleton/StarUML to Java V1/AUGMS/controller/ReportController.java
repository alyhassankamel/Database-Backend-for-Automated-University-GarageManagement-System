package controller;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ReportController {

    /**
     * Default constructor
     */
    public ReportController() {
    }



    /**
     * @return
     */
    public void handleUsageReportRequest() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void handleReportGeneration() {
        // TODO implement here
        return null;
    }

}