package controller;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class VehicleManagementController {

    /**
     * Default constructor
     */
    public VehicleManagementController() {
    }



    /**
     * @return
     */
    public void handleLogin() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void handlePendingRegistrationsRequest() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void handleUserAction() {
        // TODO implement here
        return null;
    }

}