package controller;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class UserRegistrationService {

    /**
     * Default constructor
     */
    public UserRegistrationService() {
    }

}