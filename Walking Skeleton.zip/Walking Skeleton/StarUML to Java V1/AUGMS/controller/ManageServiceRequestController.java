package controller;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ManageServiceRequestController {

    /**
     * Default constructor
     */
    public ManageServiceRequestController() {
    }



    /**
     * @return
     */
    public void handleRequestManagement() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void handleRequestActionChange() {
        // TODO implement here
        return null;
    }

}