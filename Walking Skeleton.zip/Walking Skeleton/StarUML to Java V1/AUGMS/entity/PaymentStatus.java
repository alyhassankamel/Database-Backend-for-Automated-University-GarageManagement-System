package entity;

/**
 * 
 */
enum PaymentStatus {
    SUCCESS,
    FAILED,
    PENDING
}