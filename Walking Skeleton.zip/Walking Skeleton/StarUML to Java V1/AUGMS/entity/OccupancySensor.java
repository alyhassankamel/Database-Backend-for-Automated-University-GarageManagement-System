package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class OccupancySensor extends Sensor {

    /**
     * Default constructor
     */
    public OccupancySensor() {
    }

    /**
     * 
     */
    private String spotID;

    /**
     * 
     */
    private void isOccupied;



    /**
     * @return
     */
    public void detectOccupancy() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void getOccupancyState() {
        // TODO implement here
        return null;
    }

    /**
     * @param occupied 
     * @return
     */
    public void updateOccupancyStatus(void occupied) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void notifyParkingSpotOnStatusChange() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void detectOccupancyError() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public SensorAlert generateOccupancyErrorAlert() {
        // TODO implement here
        return null;
    }

    /**
     * @param alert 
     * @return
     */
    public void transmitAlert(SensorAlert alert) {
        // TODO implement here
        return null;
    }

}