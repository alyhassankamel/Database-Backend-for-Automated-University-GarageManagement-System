package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class UsageReport {

    /**
     * Default constructor
     */
    public UsageReport() {
    }

    /**
     * 
     */
    private String reportID;

    /**
     * 
     */
    private void startDate;

    /**
     * 
     */
    private void endDate;

    /**
     * 
     */
    private String format;




    /**
     * @return
     */
    public String getReportID() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public Document generateReport() {
        // TODO implement here
        return null;
    }

}