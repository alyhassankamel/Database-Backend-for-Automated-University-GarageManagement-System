package entity;

/**
 * 
 */
enum GateStatus {
    OPEN,
    CLOSED,
    ERROR
}