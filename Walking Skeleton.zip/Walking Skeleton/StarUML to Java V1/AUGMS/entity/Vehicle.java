package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Vehicle {

    /**
     * Default constructor
     */
    public Vehicle() {
    }

    /**
     * 
     */
    private String vehicleID;

    /**
     * 
     */
    private String licensePlate;

    /**
     * 
     */
    private String model;

    /**
     * 
     */
    private String color;

    /**
     * 
     */
    private void accessStatus;




    /**
     * @return
     */
    public String getVehicleID() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String getLicensePlate() {
        // TODO implement here
        return "";
    }

    /**
     * @param details 
     * @return
     */
    public void updateDetails(void details) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void associateVehicle() {
        // TODO implement here
        return null;
    }

}