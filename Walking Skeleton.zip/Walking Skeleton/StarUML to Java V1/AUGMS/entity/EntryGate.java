package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class EntryGate {

    /**
     * Default constructor
     */
    public EntryGate() {
    }

    /**
     * 
     */
    private String gateID;

    /**
     * 
     */
    private GateStatus status;


    /**
     * @return
     */
    public void openGate() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void closeGate() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void confirmGateOpened() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public GateStatus getGateStatus() {
        // TODO implement here
        return null;
    }

}