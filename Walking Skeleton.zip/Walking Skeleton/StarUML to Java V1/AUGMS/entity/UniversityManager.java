package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class UniversityManager {

    /**
     * Default constructor
     */
    public UniversityManager() {
    }

    /**
     * 
     */
    private String uniID;

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private String phone;

    /**
     * 
     */
    private String managerID;


    /**
     * @param alert 
     * @return
     */
    public void receiveSystemWideAlert(SensorAlert alert) {
        // TODO implement here
        return null;
    }

    /**
     * @param garageID 
     * @param access 
     * @return
     */
    public void manageGarageAccess(String garageID, void access) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> reviewAlertPatterns() {
        // TODO implement here
        return null;
    }

    /**
     * @param action 
     * @return
     */
    public void authorizeEscalationActions(String action) {
        // TODO implement here
        return null;
    }

}