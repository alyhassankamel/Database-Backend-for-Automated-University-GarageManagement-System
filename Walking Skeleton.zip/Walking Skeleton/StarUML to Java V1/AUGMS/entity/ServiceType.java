package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ServiceType {

    /**
     * Default constructor
     */
    public ServiceType() {
    }

    /**
     * 
     */
    private String serviceID;

    /**
     * 
     */
    private String serviceName;

    /**
     * 
     */
    private String description;

    /**
     * 
     */
    private Double price;



    /**
     * @return
     */
    public String getServiceID() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String getServiceName() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public Double getPrice() {
        // TODO implement here
        return null;
    }

}