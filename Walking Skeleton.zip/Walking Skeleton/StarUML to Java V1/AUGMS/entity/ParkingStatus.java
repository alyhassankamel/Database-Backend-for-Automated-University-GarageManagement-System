package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ParkingStatus {

    /**
     * Default constructor
     */
    public ParkingStatus() {
    }

    /**
     * 
     */
    private String garageID;

    /**
     * 
     */
    private int availableSpots;

    /**
     * 
     */
    private int occupiedSpots;

    /**
     * 
     */
    private int totalSpots;

    /**
     * 
     */
    private void timestamp;


    /**
     * @return
     */
    public int getAvailableSpots() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public int getOccupiedSpots() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public int getTotalSpots() {
        // TODO implement here
        return 0;
    }

}