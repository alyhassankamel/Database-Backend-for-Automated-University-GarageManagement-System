package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class EntryExitLog {

    /**
     * Default constructor
     */
    public EntryExitLog() {
    }

    /**
     * 
     */
    private String logID;

    /**
     * 
     */
    private String licensePlate;

    /**
     * 
     */
    private void timestamp;

    /**
     * 
     */
    private String type;

    /**
     * 
     */
    private Double fee;



    /**
     * @return
     */
    public String getLogID() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public void getTimestamp() {
        // TODO implement here
        return null;
    }

}