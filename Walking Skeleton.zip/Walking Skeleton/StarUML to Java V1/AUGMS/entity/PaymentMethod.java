package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class PaymentMethod {

    /**
     * Default constructor
     */
    public PaymentMethod() {
    }

    /**
     * 
     */
    private String methodID;

    /**
     * 
     */
    private String methodType;

    /**
     * 
     */
    private void details;



    /**
     * @param amount 
     * @return
     */
    public PaymentResult processPayment(Double amount) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void validateMethod() {
        // TODO implement here
        return null;
    }

}