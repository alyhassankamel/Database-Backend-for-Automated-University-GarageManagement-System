package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ExitGate {

    /**
     * Default constructor
     */
    public ExitGate() {
    }

    /**
     * 
     */
    private String gateID;

    /**
     * 
     */
    private GateStatus status;


    /**
     * @return
     */
    public void openGate() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void closeGate() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public GateStatus getGateStatus() {
        // TODO implement here
        return null;
    }

}