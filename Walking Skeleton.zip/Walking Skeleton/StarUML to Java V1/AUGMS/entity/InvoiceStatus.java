package entity;

/**
 * 
 */
enum InvoiceStatus {
    PENDING,
    PAID,
    CANCELLED
}