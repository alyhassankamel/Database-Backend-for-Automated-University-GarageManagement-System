package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ParkingUser {

    /**
     * Default constructor
     */
    public ParkingUser() {
    }

    /**
     * 
     */
    private String userID;

    /**
     * 
     */
    private String uniID;

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private String email;

    /**
     * 
     */
    private String phone;

    /**
     * 
     */
    private String role;

    /**
     * 
     */
    private void accessStatus;

    /**
     * 
     */
    private void isUrgentMember;

    /**
     * 
     */
    private RegistrationStatus registrationStatus;





    /**
     * @return
     */
    public String getUserID() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String getUniID() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String getRole() {
        // TODO implement here
        return "";
    }

    /**
     * @param role 
     * @return
     */
    public void setRole(String role) {
        // TODO implement here
        return null;
    }

    /**
     * @param status 
     * @return
     */
    public void updateAccess(void status) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void confirmUpdate() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getVehicles() {
        // TODO implement here
        return null;
    }

    /**
     * @param vehicle 
     * @return
     */
    public void addVehicle(Vehicle vehicle) {
        // TODO implement here
        return null;
    }

}