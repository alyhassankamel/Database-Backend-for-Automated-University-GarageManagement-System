package entity;

/**
 * 
 */
enum RequestStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}