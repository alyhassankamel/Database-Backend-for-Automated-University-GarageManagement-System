package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Log {

    /**
     * Default constructor
     */
    public Log() {
    }

    /**
     * 
     */
    private String logID;

    /**
     * 
     */
    private String userID;

    /**
     * 
     */
    private String vehicleID;

    /**
     * 
     */
    private String actionType;

    /**
     * 
     */
    private void date;

    /**
     * 
     */
    private String details;

    /**
     * 
     */
    private String type;



    /**
     * @return
     */
    public String getLogID() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String getActionType() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String getDetails() {
        // TODO implement here
        return "";
    }

}