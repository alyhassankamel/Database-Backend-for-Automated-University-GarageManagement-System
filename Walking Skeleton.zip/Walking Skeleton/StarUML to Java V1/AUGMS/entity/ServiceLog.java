package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ServiceLog {

    /**
     * Default constructor
     */
    public ServiceLog() {
    }

    /**
     * 
     */
    private String logID;

    /**
     * 
     */
    private String requestID;

    /**
     * 
     */
    private String serviceID;

    /**
     * 
     */
    private void timestamp;

    /**
     * 
     */
    private String status;



    /**
     * @return
     */
    public String getLogID() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public void getTimestamp() {
        // TODO implement here
        return null;
    }

}