package entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ParkingGarage {

    /**
     * Default constructor
     */
    public ParkingGarage() {
    }

    /**
     * 
     */
    private String garageID;

    /**
     * 
     */
    private void garageAccess;

    /**
     * 
     */
    private int availableSpotCount;

    /**
     * 
     */
    private int totalSpots;



    /**
     * @return
     */
    public String getGarageID() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public int countAvailableSlots() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public int countOccupiedSlots() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public Set<void> getAvailableSpots() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getOccupiedSpots() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public ParkingStatus getParkingStatus() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void isGarageAccessible() {
        // TODO implement here
        return null;
    }

}