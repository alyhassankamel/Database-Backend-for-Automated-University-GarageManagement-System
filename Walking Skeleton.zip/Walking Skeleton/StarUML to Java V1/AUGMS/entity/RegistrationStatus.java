package entity;

/**
 * 
 */
enum RegistrationStatus {
    PENDING,
    APPROVED,
    REJECTED
}