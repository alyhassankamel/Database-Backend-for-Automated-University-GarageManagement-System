package dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class LoggingDAO {

    /**
     * Default constructor
     */
    public LoggingDAO() {
    }



    /**
     * @return
     */
    public void createLog() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void findLog() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getLogsByType() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getLogsByDateRange() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getErrorLogs() {
        // TODO implement here
        return null;
    }

}