package dao;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ServiceRequestDAO {

    /**
     * Default constructor
     */
    public ServiceRequestDAO() {
    }




    /**
     * @return
     */
    public void createRequest() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void findRequest() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void updateRequestStatus() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public Set<void> getRequestsByUser() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getRequestsBySpot() {
        // TODO implement here
        return null;
    }

}