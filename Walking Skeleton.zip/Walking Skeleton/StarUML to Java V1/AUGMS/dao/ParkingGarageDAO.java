package dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ParkingGarageDAO {

    /**
     * Default constructor
     */
    public ParkingGarageDAO() {
    }





    /**
     * @return
     */
    public void findGarage() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getAllGarages() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void updateGarage() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public int getAvailableSpotCount() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public int getOccupiedSpotCount() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public void incrementOccupiedSpots() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void decrementOccupiedSpots() {
        // TODO implement here
        return null;
    }

}