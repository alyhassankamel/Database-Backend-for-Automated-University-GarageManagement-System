package dao;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ParkingUserDAO {

    /**
     * Default constructor
     */
    public ParkingUserDAO() {
    }







    /**
     * @return
     */
    public void createUser() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void findUser() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void findUserByUniID() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void updateUser() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void updateAccessStatus() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getPendingRegistrations() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void deleteUser() {
        // TODO implement here
        return null;
    }

}