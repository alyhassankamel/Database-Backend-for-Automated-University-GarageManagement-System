package dao;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class VehicleDAO {

    /**
     * Default constructor
     */
    public VehicleDAO() {
    }








    /**
     * @return
     */
    public void createVehicle() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void findVehicle() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void findVehicleByLicensePlate() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void updateVehicle() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void deleteVehicle() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void validateVehicleOwnership() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getVehiclesByUser() {
        // TODO implement here
        return null;
    }

}