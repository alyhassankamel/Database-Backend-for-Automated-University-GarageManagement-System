package dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class OccupancySensorDAO {

    /**
     * Default constructor
     */
    public OccupancySensorDAO() {
    }






    /**
     * @return
     */
    public void findSensor() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void findSensorBySpot() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getAllSensors() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void updateSensorStatus() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void detectOccupancy() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void getOccupancyState() {
        // TODO implement here
        return null;
    }

}