package dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ServiceTypeDAO {

    /**
     * Default constructor
     */
    public ServiceTypeDAO() {
    }



    /**
     * @return
     */
    public void findServiceType() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getAllServiceTypes() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getAvailableServicesForSpot() {
        // TODO implement here
        return null;
    }

}