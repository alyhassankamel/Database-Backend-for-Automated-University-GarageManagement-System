package dao;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ParkingSpotDAO {

    /**
     * Default constructor
     */
    public ParkingSpotDAO() {
    }




    /**
     * @return
     */
    public void findSpot() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getAllSpots() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getAvailableSpots() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getOccupiedSpots() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void updateSpotStatus() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public Set<void> getSpotsByGarage() {
        // TODO implement here
        return null;
    }

}