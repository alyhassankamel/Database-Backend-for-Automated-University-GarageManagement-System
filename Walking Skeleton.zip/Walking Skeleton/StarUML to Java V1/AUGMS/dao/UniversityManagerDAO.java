package dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class UniversityManagerDAO {

    /**
     * Default constructor
     */
    public UniversityManagerDAO() {
    }





    /**
     * @return
     */
    public void findManager() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void findManagerByUniID() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void updateManager() {
        // TODO implement here
        return null;
    }

}