package dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ServiceLogRepository {

    /**
     * Default constructor
     */
    public ServiceLogRepository() {
    }



    /**
     * @return
     */
    public Set<void> getServiceLogs() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void createServiceLog() {
        // TODO implement here
        return null;
    }

}