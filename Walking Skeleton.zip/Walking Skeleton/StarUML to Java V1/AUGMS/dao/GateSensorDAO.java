package dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class GateSensorDAO {

    /**
     * Default constructor
     */
    public GateSensorDAO() {
    }



    /**
     * @return
     */
    public void findSensor() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String scanLicensePlate() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public void detectGateError() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void getGateStatus() {
        // TODO implement here
        return null;
    }

}