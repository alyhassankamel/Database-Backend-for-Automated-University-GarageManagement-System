package dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class EntryExitRepository {

    /**
     * Default constructor
     */
    public EntryExitRepository() {
    }



    /**
     * @return
     */
    public Set<void> getEntryExitLogs() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void createEntryLog() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void createExitLog() {
        // TODO implement here
        return null;
    }

}