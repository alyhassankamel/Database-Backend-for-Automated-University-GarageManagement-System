package dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class InvoiceDAO {

    /**
     * Default constructor
     */
    public InvoiceDAO() {
    }




    /**
     * @return
     */
    public void createInvoice() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void findInvoice() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void updateInvoice() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<void> getInvoicesByRequest() {
        // TODO implement here
        return null;
    }

}