package view;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ManageServiceRequestView {

    /**
     * Default constructor
     */
    public ManageServiceRequestView() {
    }

    /**
     * 
     */
    private final void controller;


    /**
     * @return
     */
    public void displayAllRequests() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void submitRequestActionChange() {
        // TODO implement here
        return null;
    }

}