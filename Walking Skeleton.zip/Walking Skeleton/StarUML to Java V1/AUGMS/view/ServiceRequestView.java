package view;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ServiceRequestView {

    /**
     * Default constructor
     */
    public ServiceRequestView() {
    }

    /**
     * 
     */
    private final void controller;


    /**
     * @return
     */
    public void initiateServiceRequest() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayAvailableServices() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayInvoice() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayPaymentOptions() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayResult() {
        // TODO implement here
        return null;
    }

}