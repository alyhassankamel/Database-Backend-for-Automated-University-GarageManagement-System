package view;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class VehicleManagementView {

    /**
     * Default constructor
     */
    public VehicleManagementView() {
    }

    /**
     * 
     */
    private final void controller;


    /**
     * @return
     */
    public void displayPendingRegistrations() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayUserDetails() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayConfirmation() {
        // TODO implement here
        return null;
    }

}