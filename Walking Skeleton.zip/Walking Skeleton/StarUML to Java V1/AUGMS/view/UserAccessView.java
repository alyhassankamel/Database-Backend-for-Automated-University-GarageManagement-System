package view;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class UserAccessView {

    /**
     * Default constructor
     */
    public UserAccessView() {
    }

    /**
     * 
     */
    private final void controller;


    /**
     * @return
     */
    public void submitAccessChange() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayConfirmation() {
        // TODO implement here
        return null;
    }

}