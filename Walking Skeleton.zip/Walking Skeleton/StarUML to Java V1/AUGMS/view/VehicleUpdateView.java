package view;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class VehicleUpdateView {

    /**
     * Default constructor
     */
    public VehicleUpdateView() {
    }

    /**
     * 
     */
    private final void controller;


    /**
     * @return
     */
    public void displayVehicleDetails() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void submitVehicleUpdate() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayUpdateConfirmation() {
        // TODO implement here
        return null;
    }

}