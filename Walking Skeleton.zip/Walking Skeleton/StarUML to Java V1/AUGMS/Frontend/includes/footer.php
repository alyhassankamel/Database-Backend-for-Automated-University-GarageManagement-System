    <footer class="footer">
        <p>&copy; <?= date('Y') ?> Egypt University of Informatics - Parking Management System</p>
        <div class="footer-links">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Contact Us</a>
        </div>
    </footer>
    
    <script src="script.js"></script>
</body>
</html>