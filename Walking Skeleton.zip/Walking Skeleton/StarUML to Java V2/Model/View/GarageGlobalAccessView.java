package View;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class GarageGlobalAccessView {

    /**
     * Default constructor
     */
    public GarageGlobalAccessView() {
    }

    /**
     * 
     */
    private final void controller;


    /**
     * @param garage 
     * @return
     */
    public void displayCurrentStatus(void garage) {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @param accessMode 
     * @return
     */
    public void showOverrideConfirmation(String accessMode) {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displaySuccess() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayError() {
        // TODO implement here
        return null;
    }

}