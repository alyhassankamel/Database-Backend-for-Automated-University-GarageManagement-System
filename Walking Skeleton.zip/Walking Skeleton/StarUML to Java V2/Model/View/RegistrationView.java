package View;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class RegistrationView {

    /**
     * Default constructor
     */
    public RegistrationView() {
    }

    /**
     * 
     */
    private final void controller;


    /**
     * @return
     */
    public void submitRegistrationDetails() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayConfirmation() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayError() {
        // TODO implement here
        return null;
    }

}