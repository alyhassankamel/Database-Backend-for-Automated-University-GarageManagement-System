package View;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class SensorAlertView {

    /**
     * Default constructor
     */
    public SensorAlertView() {
    }

    /**
     * 
     */
    private final void controller;


    /**
     * @return
     */
    public void displaySensorAlert() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayErrorLogs() {
        // TODO implement here
        return null;
    }

}