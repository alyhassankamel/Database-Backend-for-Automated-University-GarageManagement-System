package View;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ParkingStatusView {

    /**
     * Default constructor
     */
    public ParkingStatusView() {
    }

    /**
     * 
     */
    private final void controller;


    /**
     * @return
     */
    public void requestLiveOccupancy() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayLiveOccupancy() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayParkingStatus() {
        // TODO implement here
        return null;
    }

}