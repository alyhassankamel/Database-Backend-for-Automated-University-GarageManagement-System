package View;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ReportView {

    /**
     * Default constructor
     */
    public ReportView() {
    }

    /**
     * 
     */
    private final void controller;


    /**
     * @return
     */
    public void requestUsageReport() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void displayReport() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void downloadReport() {
        // TODO implement here
        return null;
    }

}